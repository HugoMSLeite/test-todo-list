export interface Todo {
  id: string;
  title: string;
  date: string;
  finish: boolean;
}
