import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, tap } from 'rxjs';
import { Todo } from './model/todo.model';

@Injectable({
  providedIn: 'root',
})
export class TodoListService {
  todoList$ = new BehaviorSubject<Todo[]>([]);

  constructor() {
    const list = JSON.parse(sessionStorage.getItem('todoList') || '[]');
    this.todoList$.next(list);
  }

  get todoList(): Observable<Todo[]> {
    return this.todoList$.asObservable();
  }

  createTodo(todo: Todo) {
    const todoList = this.todoList$.value;
    todoList.push(todo);
    sessionStorage.setItem('todoList', JSON.stringify(todoList));
    this.todoList$.next(todoList);
    return of({});
  }
}
