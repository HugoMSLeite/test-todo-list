import { TodoListService } from './todo-list.service';
import { Observable, take } from 'rxjs';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Todo } from './model/todo.model';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.scss'],
})
export class TodoListComponent implements OnInit {
  todoList: Todo[] = [];

  constructor(
    private todoListService: TodoListService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.todoListService.todoList.pipe(take(1)).subscribe((ret) => {
      this.todoList = ret;
    });
  }

  createTodo() {
    this.router.navigate(['create']);
  }
}
