import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Todo } from 'src/app/todo-list/model/todo.model';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit {
  @Input() todoList: Todo[] = [];
  @Output() finishTodo = new EventEmitter<string>();

  constructor() {}

  ngOnInit(): void {}

  finish(todo: Todo) {
    this.finishTodo.emit(todo.id);
  }
}
